powersOf2 :: [Int]
powersOf2 = iterate (*2) 1