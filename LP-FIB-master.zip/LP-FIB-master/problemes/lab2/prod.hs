prod :: [Int] -> Int

prod xs = foldl (*) 1 xs