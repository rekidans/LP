absValue :: Int -> Int 

absValue n
	| n < 0 = (-n)
	| otherwise = n