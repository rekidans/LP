# LP-FIB
Llenguatges de programació - FIB 2018 

Aquest repositori contindrà tot el que es farà durant el curs a l'assignatura de Llenguatges de programació durant el Q1 de 2018/19, està organitzat de manera que els apunts estaràn a **l'arrel del projecte** i després els diversos programes desenvolupats al laboratori estaràn a la carpeta **problemes/labX**

En cas que detecteu alguna cosa errònea, feel free to make a PR! 
